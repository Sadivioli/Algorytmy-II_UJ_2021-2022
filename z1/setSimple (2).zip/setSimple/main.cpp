#include "set.h"
using namespace std;

int MAX_ITERATIONS = 20;
int dataSize = 10;

int main(){
    

    //double timeIns[MAX_ITERATIONS], timeRm[MAX_ITERATIONS], timeCont[MAX_ITERATIONS];

    int iteration = 0;

    printf("Rozmiar, Dodawanie, Usuwanie, Zawieranie\n");

    while(iteration++ < MAX_ITERATIONS){

        setSimple A(dataSize);
        setSimple B(dataSize);
        setSimple C(dataSize); //zbiór C będzie kopią zbioru A, żeby sprawdzić operacje ==
       
        //tworzenie zbiorów
        srand(time(NULL));
        for(int i = 0; i < dataSize; i++){
            int x = rand() % dataSize;
            A.insert(x);
            C.insert(x);
        }
        for(int i = 0; i < dataSize; i++){
            int x = rand() % dataSize;
            B.insert(x);
        }
        if(iteration == 1){
            cout << "A: ";
            A.print();

            cout << "B: ";
            B.print();

            cout << "A u B: ";
            (A + B).print();

            cout << "A n B: ";
            (A * B).print();

            cout << "A - B: ";
            (A - B).print();

            cout << "B - A: ";
            (B - A).print();


            cout << "A == B: " << (A == B) << endl;
            cout << "A == C: " << (A == C) << endl;
        }
        
        //przeprowazamy operacje dodawania i usuwania elementów ze zbioru
        //do pliku będziemy zapisywać ilość wykonanych operacji
        
        cout << "Operacje na plikach" << endl;

        ofstream insFile("ins.txt", ios::in | ios::app);
        srand(time(NULL));
        int toInsert = rand() % dataSize;
        int insCount = A.insert(toInsert);
        cout << "Wartość zwrcana przez insert: " << insCount << endl;

        //zapis danych do pliku 
        insFile << dataSize << ", " << insCount << endl;

        insFile.close();

        dataSize += 10;
    }
   
    return 0;
}